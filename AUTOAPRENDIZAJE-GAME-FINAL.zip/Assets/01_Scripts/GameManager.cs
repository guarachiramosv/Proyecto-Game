using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    [Header("Configuración de ronda")]
    public float tiempoRonda = 10f;
    public int cantidadCelulas = 15;

    [Header("Camuflaje")]
    [Range(0.001f, 0.05f)] public float tasaMutacion = 0.003f;
    [Range(0.01f, 0.3f)] public float rangoColorInicial = 0.06f;
    [Range(0.01f, 0.2f)] public float rangoColorPorRonda = 0.03f;
    [Range(0.1f, 1f)] public float alfaCelula = 0.78f;

    [Header("Selección")]
    [Range(1, 10)] public int maxGenesGuardados = 5;
    [Range(0.1f, 1f)] public float umbralCamuflaje = 0.90f;

    [Header("Referencias")]
    public Camera camaraPrincipal;
    public GameObject celulaPrefab;

    [Header("Color del fondo")]
    public Color colorFondoActual = Color.green;

    [Header("UI")]
    public TextMeshProUGUI textoPuntos;
    public TextMeshProUGUI textoRonda;
    public TextMeshProUGUI textoTimer;

    [Header("Efectos")]
    public GameObject efectoBurbujasPrefab;

    private float cronometro;
    private int rondaActual = 1;
    private int puntos = 0;
    private bool rondaActiva = false;

    private List<Color> genesColor = new List<Color>();
    private List<Vector3> genesEscala = new List<Vector3>();
    private List<float> genesVelocidad = new List<float>();

    private class DatosSuperviviente
    {
        public Color color;
        public Vector3 escala;
        public float velocidad;
        public float similitud;
    }

    void Start()
    {
        if (camaraPrincipal == null)
            camaraPrincipal = Camera.main;

        ActualizarFondo();
        IniciarNuevaRonda();
    }

    void Update()
    {
        if (!rondaActiva) return;

        if (cronometro > 0)
        {
            cronometro -= Time.deltaTime;

            if (textoTimer != null)
                textoTimer.text = "Tiempo: " + Mathf.CeilToInt(cronometro);
        }
        else
        {
            FinalizarRonda();
        }
    }

    void ActualizarFondo()
    {
        if (camaraPrincipal != null)
        {
            camaraPrincipal.clearFlags = CameraClearFlags.SolidColor;
            camaraPrincipal.backgroundColor = colorFondoActual;
        }
    }

    float CalcularSimilitud(Color a, Color b)
    {
        float distancia = Mathf.Sqrt(
            Mathf.Pow(a.r - b.r, 2f) +
            Mathf.Pow(a.g - b.g, 2f) +
            Mathf.Pow(a.b - b.b, 2f)
        );

        float similitud = 1f - (distancia / 1.732f);
        return Mathf.Clamp01(similitud);
    }

    Color GenerarColorCercanoAlFondo(float rango)
    {
        Color fondo = camaraPrincipal.backgroundColor;

        float r = Mathf.Clamp01(fondo.r + Random.Range(-rango, rango));
        float g = Mathf.Clamp01(fondo.g + Random.Range(-rango, rango));
        float b = Mathf.Clamp01(fondo.b + Random.Range(-rango, rango));

        return new Color(r, g, b, alfaCelula);
    }

    Color CorregirColorHaciaFondo(Color colorBase, float fuerza)
    {
        Color fondo = camaraPrincipal.backgroundColor;

        float r = Mathf.Lerp(colorBase.r, fondo.r, fuerza) + Random.Range(-tasaMutacion, tasaMutacion);
        float g = Mathf.Lerp(colorBase.g, fondo.g, fuerza) + Random.Range(-tasaMutacion, tasaMutacion);
        float b = Mathf.Lerp(colorBase.b, fondo.b, fuerza) + Random.Range(-tasaMutacion, tasaMutacion);

        return new Color(
            Mathf.Clamp01(r),
            Mathf.Clamp01(g),
            Mathf.Clamp01(b),
            alfaCelula
        );
    }

    void IniciarNuevaRonda()
    {
        cronometro = tiempoRonda;
        rondaActiva = true;
        ActualizarFondo();

        float rangoActual = Mathf.Max(0.01f, rangoColorInicial - ((rondaActual - 1) * rangoColorPorRonda));

        for (int i = 0; i < cantidadCelulas; i++)
        {
            Vector3 pos = new Vector3(
                Random.Range(-6f, 6f),
                Random.Range(-3.5f, 3.5f),
                0f
            );

            GameObject nuevaCelula = Instantiate(celulaPrefab, pos, Quaternion.identity);
            AplicarGenes(nuevaCelula, rangoActual);
        }

        ActualizarInterfaz();
    }

    void AplicarGenes(GameObject celula, float rangoActual)
    {
        SpriteRenderer sr = celula.GetComponent<SpriteRenderer>();
        MovimientoCelula mov = celula.GetComponent<MovimientoCelula>();

        if (sr == null) return;
        if (mov == null) mov = celula.AddComponent<MovimientoCelula>();

        if (genesColor.Count > 0)
        {
            int i = Random.Range(0, genesColor.Count);

            // El gen heredado SIEMPRE se corrige hacia el fondo
            Color colorFinal = CorregirColorHaciaFondo(genesColor[i], 0.92f);
            sr.color = colorFinal;

            Vector3 escalaPadre = genesEscala[i];
            celula.transform.localScale = escalaPadre * Random.Range(0.98f, 1.02f);

            float velocidadPadre = genesVelocidad[i];
            mov.velocidad = Mathf.Clamp(velocidadPadre + Random.Range(-0.01f, 0.01f), 0.35f, 0.8f);
        }
        else
        {
            sr.color = GenerarColorCercanoAlFondo(rangoActual);

            float tam = Random.Range(0.9f, 1.1f);
            celula.transform.localScale = new Vector3(tam, tam, 1f);

            mov.velocidad = Random.Range(0.4f, 0.7f);
        }
    }

    void FinalizarRonda()
    {
        rondaActiva = false;

        GameObject[] supervivientes = GameObject.FindGameObjectsWithTag("Celula");
        List<DatosSuperviviente> candidatos = new List<DatosSuperviviente>();

        foreach (GameObject s in supervivientes)
        {
            SpriteRenderer sr = s.GetComponent<SpriteRenderer>();
            MovimientoCelula mov = s.GetComponent<MovimientoCelula>();

            if (sr != null && mov != null)
            {
                // Antes de guardar el gen, lo medimos contra el fondo
                float similitud = CalcularSimilitud(sr.color, camaraPrincipal.backgroundColor);

                DatosSuperviviente dato = new DatosSuperviviente();
                dato.color = sr.color;
                dato.escala = s.transform.localScale;
                dato.velocidad = mov.velocidad;
                dato.similitud = similitud;

                candidatos.Add(dato);
            }
        }

        candidatos.Sort((a, b) => b.similitud.CompareTo(a.similitud));

        genesColor.Clear();
        genesEscala.Clear();
        genesVelocidad.Clear();

        int cantidad = Mathf.Min(maxGenesGuardados, candidatos.Count);

        for (int i = 0; i < cantidad; i++)
        {
            Color colorCorregido = CorregirColorHaciaFondo(candidatos[i].color, 0.95f);

            // Solo guardamos genes ya corregidos hacia el fondo
            genesColor.Add(colorCorregido);
            genesEscala.Add(candidatos[i].escala);
            genesVelocidad.Add(candidatos[i].velocidad);
        }

        // Si no quedó nada, crear genes nuevos directamente cerca del fondo
        if (genesColor.Count == 0)
        {
            for (int i = 0; i < maxGenesGuardados; i++)
            {
                genesColor.Add(GenerarColorCercanoAlFondo(0.02f));
                genesEscala.Add(new Vector3(1f, 1f, 1f));
                genesVelocidad.Add(Random.Range(0.4f, 0.7f));
            }
        }

        foreach (GameObject s in supervivientes)
        {
            Destroy(s);
        }

        rondaActual++;
        IniciarNuevaRonda();
    }

    public void SumarPuntos(Vector3 posicion, Color colorOriginal)
    {
        puntos++;

        if (efectoBurbujasPrefab != null)
        {
            GameObject efecto = Instantiate(efectoBurbujasPrefab, posicion, Quaternion.identity);
            Destroy(efecto, 1f);
        }

        ActualizarInterfaz();
    }

    void ActualizarInterfaz()
    {
        if (textoPuntos != null)
            textoPuntos.text = "Puntos: " + puntos;

        if (textoRonda != null)
            textoRonda.text = "Ronda: " + rondaActual;

        if (textoTimer != null)
            textoTimer.text = "Tiempo: " + Mathf.CeilToInt(cronometro);
    }

    public void CambiarColorFondo(Color nuevoColor)
    {
        colorFondoActual = nuevoColor;
        ActualizarFondo();
    }
}