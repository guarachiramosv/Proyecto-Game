using UnityEngine;

public class InteraccionCelula : MonoBehaviour
{
    private GameManager gameManager;
    private SpriteRenderer spriteRenderer;

    void Start()
    {
       
        gameManager = Object.FindFirstObjectByType<GameManager>();

        // Guardamos para saver el color de la celula
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void Matar()
    {
        if (gameManager != null)
        {
            // Obtenemos ek color actual de nuestra celula
            Color colorDeMuerte = (spriteRenderer != null) ? spriteRenderer.color : Color.white;

            // con esto mandamos la ubicacion
            gameManager.SumarPuntos(transform.position, colorDeMuerte);
        }

        Destroy(gameObject); //aca muere la celula
    }
}