using UnityEngine;

public class MovimientoCelula : MonoBehaviour
{
 
 public float velocidad = 2f;

    public float rangoX = 7f;
    public float rangoY = 4f;

    private Vector2 puntoDestino;

    void Start()
    {
        ElegirNuevoDestino();
       
        transform.position = new Vector3(transform.position.x, transform.position.y, 0);
    }

    void Update()
    {
        // Movimiento suave hacia el punto aleatorio
        transform.position = Vector2.MoveTowards(transform.position, puntoDestino, velocidad * Time.deltaTime);

        // Si llega al destino o está muy cerca, elige otro punto
        if (Vector2.Distance(transform.position, puntoDestino) < 0.2f)
        {
            ElegirNuevoDestino();
        }
    }

    void ElegirNuevoDestino()
    {
        // Crea un punto al azar dentro de los límites de tu cámara
        puntoDestino = new Vector2(Random.Range(-rangoX, rangoX), Random.Range(-rangoY, rangoY));
    }
}