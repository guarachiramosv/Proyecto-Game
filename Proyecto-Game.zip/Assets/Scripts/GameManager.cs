using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    [Header("Machine Learning: Genes")]
    public float tiempoRonda = 10f;
    private float cronometro;
    private int rondaActual = 1;

    // Listas para guardar el "ADN" de los supervivientes
    private List<Color> genesColor = new List<Color>();
    private List<Vector3> genesEscala = new List<Vector3>();

    [Header("Ajustes de Escena")]
    public Camera camaraPrincipal;
    public Color colorFondoActual;
    public GameObject celulaPrefab;
    public int cantidadCelulas = 15;

    [Header("Interfaz UI")]
    public TextMeshProUGUI textoPuntos;
    public TextMeshProUGUI textoRonda;
    public TextMeshProUGUI textoTimer;

    private int puntos = 0;

    void Start()
    {
        if (camaraPrincipal == null) camaraPrincipal = Camera.main;
        IniciarNuevaRonda();
    }

    void Update()
    {
        // FUERZA BRUTA: Esto obliga al fondo a ser rosa SIEMPRE
        if (camaraPrincipal != null)
        {
            camaraPrincipal.clearFlags = CameraClearFlags.SolidColor;
            camaraPrincipal.backgroundColor = colorFondoActual;
        }

        if (cronometro > 0)
        {
            cronometro -= Time.deltaTime;
            if (textoTimer != null) textoTimer.text = "Tiempo: " + Mathf.Ceil(cronometro);
        }
        else
        {
            FinalizarRonda();
        }
    }

    void IniciarNuevaRonda()
    {
        cronometro = tiempoRonda;
        for (int i = 0; i < cantidadCelulas; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-7f, 7f), Random.Range(-4f, 4f), 0);
            GameObject nueva = Instantiate(celulaPrefab, pos, Quaternion.identity);
            AplicarGenes(nueva);
        }
        ActualizarInterfaz();
    }

    void AplicarGenes(GameObject celula)
    {
        SpriteRenderer sr = celula.GetComponent<SpriteRenderer>();

        // Si hay supervivientes, heredan su tamaño y color
        if (genesColor.Count > 0)
        {
            int indiceAzar = Random.Range(0, genesColor.Count);

            // Herencia con MUTACIÓN (Color)
            Color c = genesColor[indiceAzar];
            c.r += Random.Range(-0.15f, 0.15f);
            c.g += Random.Range(-0.15f, 0.15f);
            c.b += Random.Range(-0.15f, 0.15f);
            sr.color = c;

            // Herencia con MUTACIÓN (Tamaño)
            Vector3 s = genesEscala[indiceAzar];
            float mod = Random.Range(0.8f, 1.2f); // Cambia el tamaño un 20%
            celula.transform.localScale = s * mod;
        }
        else
        {
            // RONDA 1: Todo es aleatorio para empezar la evolución
            sr.color = new Color(Random.value, Random.value, Random.value);
            float tam = Random.Range(0.5f, 2.5f);
            celula.transform.localScale = new Vector3(tam, tam, 1);
        }
    }

    void FinalizarRonda()
    {
        // VITAL: El prefab DEBE tener el Tag "Celula"
        GameObject[] supervivientes = GameObject.FindGameObjectsWithTag("Celula");

        genesColor.Clear();
        genesEscala.Clear();

        foreach (GameObject s in supervivientes)
        {
            genesColor.Add(s.GetComponent<SpriteRenderer>().color);
            genesEscala.Add(s.transform.localScale);
            Destroy(s);
        }
        rondaActual++;
        IniciarNuevaRonda();
    }

    public void SumarPuntos() { puntos++; ActualizarInterfaz(); }
    void ActualizarInterfaz()
    {
        if (textoPuntos != null) textoPuntos.text = "Puntos: " + puntos;
        if (textoRonda != null) textoRonda.text = "Ronda: " + rondaActual;
    }
}