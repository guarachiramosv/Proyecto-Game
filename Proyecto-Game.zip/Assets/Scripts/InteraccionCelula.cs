using UnityEngine;

public class InteraccionCelula : MonoBehaviour
{
    private GameManager gameManager;

    void Start()
    {
        // Busca el GameManager en la escena
        gameManager = Object.FindFirstObjectByType<GameManager>();
    }

    // Este método se activa cuando haces clic en la célula (si tienes el EventTrigger)
    public void Matar()
    {
        if (gameManager != null)
        {
            gameManager.SumarPuntos(); // Llamamos a la función correcta
        }

        Destroy(gameObject); // La célula muere
    }
}